#Headlines
# This Priject where created by: Ali Orabi (aliorabi0@gmail.com)
RSS-headlines News

#Description

A news summary site! You can display recent news from a number of different websites, see the headline, date, and summary for each recent article, and can click on any headline to visit the original article.
#Dependency

    Python3 / Flask
    Feedparser RSS/Feeds lib
    json, urllib, request, urllib.parse

#Handling User inputs

Getting user input using HTTP GET Getting user input using HTTP POST Creating a branch in Git Adding POST routes in Flask Making our HTML form use POST Reverting our Git repository Adding weather and currency data Introducing the OpenWeatherMap API Signing up with OpenWeatherMap Retrieving your OpenWeatherMap API key Parsing JSON with Python Introducing JSON Retrieving and parsing JSON in Python Using our weather code Displaying the weather data Allowing the user to customize the city Adding another search box to our template Using the user's city search in our Python code Checking our new functionality Handling duplicate city names Currency Getting an API key for the Open Exchange Rates API Using the Open Exchange Rates API Using our currency function Displaying the currency data in our template Adding inputs for the user to select currency Creating an HTML select drop-down element Adding all the currencies to the select input Displaying the selected currency in the drop-down input
-Improving the User Experience of Our Headlines Project

-Adding cookies to our Headlines application Using cookies with Flask Setting cookies in Flask Retrieving cookies in Flask Adding CSS to our Headlines application
About

RSS-headlines News
Topics
Resources
Readme
License
MIT License
Releases
No releases published
Create a new release
Packages
No packages published
Publish your first package
